StepModulo4-Projeto-HTML_Avancado

Uso dum template para uns formularios do site, personalizado para se encontrar com os objetivos funcionais e gráficos do projeto.
Uso do Bootstrap: Caroussel, Card, Modal, Formulario.
Uso do TinySlider
Uso do LightGallery
Javascript para manipulacao de DOM e validação de formúlario