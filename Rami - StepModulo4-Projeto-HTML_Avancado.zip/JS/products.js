function paraCarinho() {
    location.href = "./carinho.html";
}

function toGallery() {
    document.getElementById('quick-view').style.display = 'none';
}